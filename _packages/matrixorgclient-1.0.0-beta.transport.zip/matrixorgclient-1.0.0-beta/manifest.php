<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '112e808112ff057489774afa6be6e034',
      'native_key' => 'matrixorgclient',
      'filename' => 'modNamespace/b8e70f652eaf205ae32c72a53899b339.vehicle',
      'namespace' => 'matrixorgclient',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '34b7a004b03654de0517e12e1e83b909',
      'native_key' => NULL,
      'filename' => 'modCategory/48060ccb10bc1fdc44c919b251a0533a.vehicle',
      'namespace' => 'matrixorgclient',
    ),
  ),
);