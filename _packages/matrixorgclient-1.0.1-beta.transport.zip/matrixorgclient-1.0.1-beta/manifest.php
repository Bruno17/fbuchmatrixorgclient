<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a1f75b2b0d776e1963eb1d64e7cfe4cf',
      'native_key' => 'matrixorgclient',
      'filename' => 'modNamespace/b9fa8515a900c2a5eae103ef7ea6d56c.vehicle',
      'namespace' => 'matrixorgclient',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '27886ea1bbcd7f4a75c0f571d08a65af',
      'native_key' => NULL,
      'filename' => 'modCategory/3d1060dc4d4534c9023f73e2229192a0.vehicle',
      'namespace' => 'matrixorgclient',
    ),
  ),
);